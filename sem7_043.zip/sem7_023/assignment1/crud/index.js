var mongoose=require('mongoose');
var express=require('express');
var app=express();
var bodyParser=require('body-parser'); 
var urlEncodedParser=bodyParser.urlencoded({extended:false});
mongoose.connect('mongodb://localhost:27017/studentdb',{ useNewUrlParser: true });
var db = mongoose.connection;
app.set('view engine','pug');
app.set('views','./view');
db.on('error',console.error.bind(console,"connection error"));
db.once('open',function(){
	console.log("connection successful!!");
	var studentSchema=mongoose.Schema({
		studentName:String,
		contactNo:Number,
		email:String,
		city:String,
		gender:String
	});
	var stud=mongoose.model('Student',studentSchema,'tblStudent');
	app.get('/showStudent',function(req,res){
		stud.find(function(err,result){
			if(err)
				throw err;
		res.render("prog7_show.pug",{"data":result});
		});
	});
	app.get('/addStudent',function(req,res){
		res.render('prog7_add.pug',{data:""})
	});
	app.get('/editStudent/:id',function(req,res){
		var id=req.params.id;
		var temp={_id:id};
		stud.findOne(temp,function(err,result){
			if (err) 
				throw err;
			res.render('prog7_add.pug',{"data":result});
		});
	});
	app.post('/submitform',urlEncodedParser,function(req,res){
		var id=req.body.txtid;
		var name=req.body.txtname;
		var cno=req.body.txtcno;
		var email=req.body.txtemail;
		var city=req.body.city;
		var gender=req.body.r1;
		console.log(id);
		if(id.length>0)
		{
			var temp = {_id:id};
			var newData = {studentName:name,contactNo:cno,email:email,city:city,gender:gender};
			stud.updateOne(temp,newData,function(err,result){
				if(err)
					throw err;
				console.log(name+" Updated");
			});
		}
		else
		{
			var s1=new stud({studentName:name,contactNo:cno,email:email,city:city,gender:gender});
			s1.save(function(err,stud){
				if(err)
					throw err;
				console.log("inserted");
			});
		}
		res.redirect('/showStudent');
	});
	app.get('/deleteStudent/:id',function(req,res){
		var temp = {_id:req.params.id};
		stud.deleteOne(temp,function(err){
			if(err)
				throw err;
			console.log("Deleted");
		});
		res.redirect("/showStudent");
	});
});
var server=app.listen(8087,function(){
	console.log("connect");
});
