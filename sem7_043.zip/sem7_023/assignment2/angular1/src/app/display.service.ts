import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DisplayService {

  constructor(private hc:HttpClient) { }

  url="http://localhost:8000";

  displaydata(){
    return this.hc.get(this.url+"/");
  }
}
