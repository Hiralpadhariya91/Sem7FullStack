const express=require("express");
var router=express.Router();
var {Employee} =require('../models/employee.js');
var ObjectId=require("mongoose").Types.ObjectId;
router.get('/',function(req,res)
{
    Employee.find(function(err,docs)
    {
        if(!err)
        res.send(docs);
        else
        {
            console.log("Error");
        }
    });
});
router.post('/',function(req,res)
{
    var emp=new Employee({
        name:req.body.name,
        salary:req.body.salary
    });
    emp.save(function(err,docs)
    {
        if(!err)
        res.send(docs);
        else
        console.log(" Error in Inserted");
    })
});
router.get('/:id',function(req,res)
{
    if(!ObjectId.isValid(req.params.id))
    return res.status(400).send("No Record Found");
    Employee.findById(req.params.id,function(err,docs)
    {
        if(!err)
        res.send(docs);
        else
        console.log(" Error in Retriving Employee");

    });
});
router.put('/:id',function(req,res)
{
    if(!ObjectId.isValid(req.params.id))
    return res.status(400).send("No Record Found");
    var emp={
        name:req.body.name,
        salary:req.body.salary
    };
    Employee.findByIdAndUpdate(req.params.id,{$set:emp},{new :true},(err,doc)=>{
        if(!err)
        res.send(doc);
        else
        console.log("Error In Update");
    });
});
router.delete('/:id',function(req,res)
{
    if(!ObjectId.isValid(req.params.id))
    return res.status(400).send("No Record Found");
    Employee.findByIdAndRemove(req.params.id,function(err,docs)
    {
        if(!err)
        res.send(docs);
        else
        console.log("Error In Delete");

    });
});
module.exports=router;
