const mongoose =require("mongoose");
mongoose.connect("mongodb://localhost:27017/Db",(err)=>{
		if(!err)
	console.log("connect");
	else
		console.log("err");
});
module.exports=mongoose;
