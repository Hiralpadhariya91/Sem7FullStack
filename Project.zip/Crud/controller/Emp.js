const express=require("express");
var router=express.Router();
var { Employee }=require("../model/employee.js");
router.get('/',function(req,res)
{
	Employee.find(function(err,docs)
	{
		if(!err)
			res.render("./view/list.html",{docs:docs});
	});
});

router.get('/edit/:id',function(req,res)
{
	Employee.findById(req.params.id,function(err,docs)
	{
		if(!err)
			res.render("./view/edit.html",{docs:docs});
	});
});
router.put('/editemp/:id',function(req,res)
{
	var emp ={
		name:req.body.name
	};
	Employee.findByIdAndUpdate(req.params.id,emp,function(err,docs)
	{
		if(!err)
			res.redirect('/');
	});
});
module.exports=router;