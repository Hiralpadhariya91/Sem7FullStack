const mongoose=require("mongoose");
var Employee=mongoose.model('Employee',{
	name:{ type : String}
});
module.exports={ Employee };